# EconBharati Website

Open `index.html` in a browser to view the website.

## Replace these placeholders
1. Student Registration button: replace `href="#"` with the Google Form registration URL.
2. Instagram / LinkedIn / Email in the footer with actual links.
3. Add official Bharati College / NCWEB logos if desired.
4. Update activity numbers and society dates after the first semester.

The page is responsive and works on desktop and mobile.
